int a=0;
int b=2;
if(!2==3){
    int a=2;
    a=a+2;
}
while(a==b){
    printf(a);
}