#ifndef COMMON_H
#define COMMON_H

#include "tree.h"
#define YYSTYPE TreeNode *

#endif